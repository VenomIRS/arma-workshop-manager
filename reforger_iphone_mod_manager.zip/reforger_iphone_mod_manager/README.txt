ARMA REFORGER IPHONE MOD MANAGER

Files:
- index.html: mobile-first mod-list web app

Features:
- Separate personal and server lists
- Search through the public ReforgerMods API (when browser/network access permits)
- Official Workshop links
- Add by 16-character mod ID or Workshop URL
- Add/remove mods, filter, copy IDs
- Save lists in this browser's localStorage
- Export/import all lists as JSON
- Export a config.json draft for the selected server list

IMPORTANT:
This is a browser app, not a native iOS app. It saves data on the device/browser where you use it.
For a reliable Home Screen install, publish index.html on a static HTTPS host (for example GitHub Pages), then open that HTTPS URL in Safari, tap Share, choose Add to Home Screen, enable Open as Web App if offered, then tap Add.
Do not open the HTML as a file and expect its saved data to sync to other devices. Export JSON backups regularly.
Workshop search relies on a public, unofficial metadata API and can be blocked by browser/network restrictions; official Workshop and external browser links remain available.
The exported server config is a draft; verify it against the server's expected config.json format before deploying.
